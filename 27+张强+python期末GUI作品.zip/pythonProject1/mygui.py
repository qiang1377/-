# 导包
import tkinter as tk
from tkinter import messagebox  # import this to fix messagebox error
# 将用户输入的信息 用Pickle提取
import pickle

#  设置窗口
from survey_gui import surveyGUi

window = tk.Tk()
window.title('欢迎来到学生情况调查系统')
window.geometry('450x300')

# 用画布来加载我的界面图片
canvas = tk.Canvas(window, height=417, width=500)
image_file = tk.PhotoImage(file='3.gif')
image = canvas.create_image(0,0, anchor='nw', image=image_file)
canvas.pack(side='top')

# 放置登录和注册标签
tk.Label(window, text='用户名: ').place(x=50, y= 150)
tk.Label(window, text='密  码: ').place(x=50, y= 190)
# 定义用户名是字符串形式
var_usr_name = tk.StringVar()
# 用户名给默认形式提示用户输入
var_usr_name.set('example@python.com')
# 将设置的默认用户名给输入的用户名位置
# 接受输入的用户名密码
entry_usr_name = tk.Entry(window, textvariable=var_usr_name)
entry_usr_name.place(x=160, y=150)
# 定义密码是字符串形式
var_usr_pwd = tk.StringVar()
# 将密码用*显示
entry_usr_pwd = tk.Entry(window, textvariable=var_usr_pwd, show='*')
entry_usr_pwd.place(x=160, y=190)
# 登录模块
def usr_login():
    # 获得 输入的用户名和密码
    usr_name = var_usr_name.get()
    usr_pwd = var_usr_pwd.get()
    # 异常处理
    try:
        # 将用户信息存储在资料夹里面
        with open('usrs_info.pickle', 'rb') as usr_file:
            usrs_info = pickle.load(usr_file)
    except FileNotFoundError:
        # 没有创建文件的情况下，就创建文件
        with open('usrs_info.pickle', 'wb') as usr_file:
            # 设置管理员用户名 和 密码
            usrs_info = {'admin': 'admin'}
            # 将管理员的信息放到资料夹中
            pickle.dump(usrs_info, usr_file)
    # 判断输入的用户名是不是在users_info里面
    if usr_name in usrs_info:
        # 如果 用户名在usrs_info里面就判断这个usr_pwd 是不是之前用户名对应的user_pwd
        if usr_pwd == usrs_info[usr_name]:
            # 登录成功 后的操作
            # 提示窗口
            # tk.messagebox.showinfo(title='欢迎进入', message='How are you? ' + usr_name)
            window.destroy()
            surveyGUi()

        else:
            tk.messagebox.showerror(message='Error, 你的密码有误，请重新输入！')
    # 如果用户名不在usrs_info中给出提示
    else:
        # is_sign_up 接受用户点击 是 或者 否
        is_sign_up = tk.messagebox.askyesno('Welcome',
                               '您还没有注册，想不想现在就注册？')
        # 如果想现在就注册 就调用 is_sign_up 进行注册
        if is_sign_up:
            usr_sign_up()
# 注册模块
def usr_sign_up():
    def sign_to_Mofan_Python():
        # 获取注册时输入的信息
        np = new_pwd.get()
        npf = new_pwd_confirm.get()
        nn = new_name.get()
        # 打开资料夹 判断注册的用户名和密码在源资料夹是否已存在
        # 做信息的比对
        with open('usrs_info.pickle', 'rb') as usr_file:
            exist_usr_info = pickle.load(usr_file)
        if np != npf:
            tk.messagebox.showerror('Error', '输入的密码和再一次输入的密码要相同！')
        elif nn in exist_usr_info:
            tk.messagebox.showerror('Error', '您注册的用户名已经存在，不允许注册!')
        else:
            # 用户名对应的密码等于新注册的密码
            exist_usr_info[nn] = np
            with open('usrs_info.pickle', 'wb') as usr_file:
                # 将信息传入到文件里面
                pickle.dump(exist_usr_info, usr_file)
            # 注册成功，给出提示
            tk.messagebox.showinfo('Welcome！', '你已成功注册!')
            # 关闭注册窗口
            window_sign_up.destroy()

    # 定义注册的窗口
    window_sign_up = tk.Toplevel(window)
    window_sign_up.geometry('350x200')
    window_sign_up.title('注册窗口')
    # 定义注册界面的用户名和密码还有再次输入
    new_name = tk.StringVar()
    new_name.set('example@python.com')
    tk.Label(window_sign_up, text='用户名: ').place(x=10, y= 10)
    entry_new_name = tk.Entry(window_sign_up, textvariable=new_name)
    entry_new_name.place(x=150, y=10)

    new_pwd = tk.StringVar()
    tk.Label(window_sign_up, text='密码: ').place(x=10, y=50)
    entry_usr_pwd = tk.Entry(window_sign_up, textvariable=new_pwd, show='*')
    entry_usr_pwd.place(x=150, y=50)
    # 重写确认密码
    new_pwd_confirm = tk.StringVar()
    tk.Label(window_sign_up, text='再次输入密码: ').place(x=10, y= 90)
    entry_usr_pwd_confirm = tk.Entry(window_sign_up, textvariable=new_pwd_confirm, show='*')
    entry_usr_pwd_confirm.place(x=150, y=90)
    # 设置按钮点击事件
    btn_comfirm_sign_up = tk.Button(window_sign_up, text='确定', command=sign_to_Mofan_Python)
    btn_comfirm_sign_up.place(x=150, y=130)

# 注册和登录的按钮
# 点击button 执行usr_login函数
btn_login = tk.Button(window, text='登录', command=usr_login)
# 放置按钮
btn_login.place(x=170, y=230)
btn_sign_up = tk.Button(window, text='注册', command=usr_sign_up)
btn_sign_up.place(x=270, y=230)

window.mainloop()