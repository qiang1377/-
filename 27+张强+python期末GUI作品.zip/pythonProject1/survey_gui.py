import tkinter
import tkinter.messagebox
import tkinter.ttk


class surveyGUi:
    root = None
    username = ""
    password0 = ""
    password1 = ""
    email = ""
    sex = None
    interestValList = []
    studentClasses = {'2018级': ['A1811', 'A1831', 'A1832', 'A1833', 'A1851', 'A1871', 'B1831', 'B1832', 'B1833'],
                      '2019级': ['A1911', 'A1931', 'A1932', 'A1933', 'A1951', 'A1971'],
                      '2020级': ['A2011', 'A2031', 'A2032', 'A2033', 'A2051', 'A2071'],
                      '2021级': ['A2111', 'A2131', 'A2132', 'A213', 'A2151', 'A2171'],

                      }
    interestVal = {
        99: "",
        0: "篮球",
        1: "弹吉他",
        2: "敲代码",
        3: "阅读",
        4: "其他"
    }
    comboGrade = None
    comboClass = None
    checkInterest0 = None
    checkInterest1 = None
    checkInterest2 = None
    checkInterest3 = None
    checkInterest4 = None
    okBtn = None
    backBtn = None
    registerBtn = None
    listboxUser = None
    usernameEn = None
    passwordEn = None
    rePasswordEn = None
    emailEn = None
    nameEn = None

    def __init__(self):
        self.createGUI()

    # 创建python GUI
    def createGUI(self):
        self.root = tkinter.Tk()
        # 设置窗口的大小
        self.root.wm_geometry("710x600+300+10")
        # 设置不允许改变窗口的高宽
        self.root.wm_resizable(False, False)
        # 设置窗口标题
        self.root.title('个人情况调查')
        self.createSubGroup()
        # self.root.mainloop()

    #   创建GUI当中的组件
    def createSubGroup(self):
        frame = tkinter.Frame(self.root)
        tkinter.Label(frame).grid(row=0)
        ## 姓名
        tkinter.Label(frame, text="姓名:").grid(row=1, column=1, stick=tkinter.W, pady=10)
        self.usernameEn = tkinter.Entry(frame, textvariable=self.username)
        self.usernameEn.grid(row=1, column=2, stick=tkinter.E)

        # 性别
        labelSex = tkinter.Label(frame, text='性别:')
        labelSex.grid(row=2, column=1, pady=10, stick=tkinter.W)
        # 与性别关联的变量，1:男；0:女，默认为男
        self.sex = tkinter.IntVar()
        self.sex.set(1)
        # 单选钮，男
        radioMan = tkinter.Radiobutton(frame, variable=self.sex, value=1, text='男')
        radioMan.grid(row=2, column=2, stick=tkinter.W)
        # 单选钮，女
        radioWoman = tkinter.Radiobutton(frame, variable=self.sex, value=0, text='女')
        radioWoman.grid(row=2, column=3, stick=tkinter.W)

        # 年龄
        tkinter.Label(frame, text="年龄:").grid(row=3, column=1, stick=tkinter.W, pady=10)
        self.passwordEn = tkinter.Entry(frame, textvariable=self.password0)
        self.passwordEn.grid(row=3, column=2, stick=tkinter.E)

        # qq
        tkinter.Label(frame, text="QQ:").grid(row=4, column=1, stick=tkinter.W, pady=10)
        self.rePasswordEn = tkinter.Entry(frame, textvariable=self.password1)
        self.rePasswordEn.grid(row=4, column=2, stick=tkinter.E)

        # 年级
        labelGrade = tkinter.Label(frame, text='年级:')
        labelGrade.grid(row=5, column=1, stick=tkinter.W, pady=10)
        # 学生年级组合框
        self.comboGrade = tkinter.ttk.Combobox(frame,
                                               values=tuple(self.studentClasses.keys()))
        self.comboGrade.grid(row=5, column=2, stick=tkinter.E)
        # 绑定组合框事件处理函数
        self.comboGrade.bind('<<ComboboxSelected>>', self.comboChange)
        labelClass = tkinter.Label(frame, text='班级:')
        labelClass.grid(row=5, column=3, stick=tkinter.E, padx=10)
        # 学生年级组合框
        self.comboClass = tkinter.ttk.Combobox(frame)
        self.comboClass.grid(row=5, column=4, stick=tkinter.E)

        labelInterest = tkinter.Label(frame, text='兴趣:')
        labelInterest.grid(row=6, column=1, pady=10, stick=tkinter.W)
        # 复选框
        self.interestValList = [tkinter.StringVar(), tkinter.StringVar(), tkinter.StringVar(), tkinter.StringVar(),
                                tkinter.StringVar()]
        self.checkInterest0 = tkinter.Checkbutton(frame, text=self.interestVal[0], variable=self.interestValList[0],
                                                  onvalue=self.interestVal[0], offvalue=self.interestVal[99])
        self.checkInterest0.grid(row=6, column=2, stick=tkinter.W)
        self.checkInterest1 = tkinter.Checkbutton(frame, text=self.interestVal[1], variable=self.interestValList[1],
                                                  onvalue=self.interestVal[1], offvalue=self.interestVal[99])
        self.checkInterest1.grid(row=6, column=3, stick=tkinter.W)
        self.checkInterest2 = tkinter.Checkbutton(frame, text=self.interestVal[2], variable=self.interestValList[2],
                                                  onvalue=self.interestVal[2], offvalue=self.interestVal[99])
        self.checkInterest2.grid(row=6, column=4, stick=tkinter.W)
        self.checkInterest3 = tkinter.Checkbutton(frame, text=self.interestVal[3], variable=self.interestValList[3],
                                                  onvalue=self.interestVal[3], offvalue=self.interestVal[99])
        self.checkInterest3.grid(row=6, column=5, stick=tkinter.W)
        self.checkInterest4 = tkinter.Checkbutton(frame, text=self.interestVal[4], variable=self.interestValList[4],
                                                  onvalue=self.interestVal[4], offvalue=self.interestVal[99])
        self.checkInterest4.grid(row=6, column=6, stick=tkinter.W)

        self.okBtn = tkinter.Button(frame, text="确认", command=self.ok)
        self.okBtn.grid(row=7, column=3, stick=tkinter.E)

        # 创建列表框组件
        self.listboxUser = tkinter.Listbox(frame, width=80, height=8, fg='red')
        Sb = tkinter.Scrollbar()
        Sb.pack(side=tkinter.RIGHT, fill=tkinter.Y)
        # 两个控件关联
        Sb.config(command=self.listboxUser.yview)
        self.listboxUser.config(yscrollcommand=Sb.set)
        self.listboxUser.grid(row=8, column=1, columnspan=6, stick=tkinter.E)
        frame.pack(side=tkinter.TOP, fill=tkinter.Y)

    # 年级班级事件处理函数
    def comboChange(self, event):
        grade = self.comboGrade.get()
        if grade:
            # 动态改变组合框可选项
            self.comboClass["values"] = self.studentClasses.get(grade)
        else:
            self.comboClass.set([])

    def ok(self):
        self.listboxUser.delete(0, self.listboxUser.size())
        result = '姓名:' + self.usernameEn.get()
        self.listboxUser.insert(1, result)

        result = '性别:' + ('男' if self.sex.get() else '女')
        self.listboxUser.insert(2, result)

        result = '年龄:' + self.passwordEn.get()
        self.listboxUser.insert(3, result)

        result = 'qq:' + self.rePasswordEn.get()
        self.listboxUser.insert(4, result)

        result = '年级:' + self.comboGrade.get()
        self.listboxUser.insert(5, result)
        result = '班级:' + self.comboClass.get()
        self.listboxUser.insert(6, result)
        result = '兴趣爱好:'
        self.listboxUser.insert(7, result)
        print(len(self.interestValList))
        for i in range(len(self.interestValList)):
            if self.interestValList[i].get() == "":
                continue

            result = (" " * 15 + "⚪" + self.interestValList[i].get())
            self.listboxUser.insert(7 + i, result)
        # self.registerBtn['state'] = 'normal'
        # result = "您的信息如上，确认无误后请点击注册按钮！！！"
        # self.listboxUser.insert(8 + len(list(filter(lambda x: x.get() != "", self.interestValList))), result)
        pass

    def tip(self, title, message):
        # self.root.destroy()
        tkinter.messagebox.showinfo(title=title, message=message)


